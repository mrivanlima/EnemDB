CREATE OR REPLACE FUNCTION app.set_year_name_friendly()
RETURNS TRIGGER AS $$
BEGIN
    NEW.year_name_friendly := unaccent(NEW.year_name);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;